Firmware package: v2.2.4_zectrix-s3-epaper-4.2
Board: zectrix-s3-epaper-4.2
Target: esp32s3
Firmware version: 2.2.4

Full-chip flashing with one merged image:
  esptool.py --chip esp32s3 -p COM9 -b 460800 --before default_reset --after hard_reset write_flash 0x0 merged-binary.bin

Component flashing:
  esptool.py --chip esp32s3 -p COM9 -b 460800 --before default_reset --after hard_reset write_flash --flash_mode dio --flash_freq 80m --flash_size 16MB 0x0 bootloader/bootloader.bin 0x8000 partition_table/partition-table.bin 0xd000 ota_data_initial.bin 0x20000 xiaozhi.bin

If the COM port differs, replace COM9.
See manifest.json for hashes and source metadata.
