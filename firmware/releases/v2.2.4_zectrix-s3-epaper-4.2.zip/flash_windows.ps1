param(
    [string]$Port = "COM9",
    [switch]$Merged
)

$ErrorActionPreference = "Stop"
$packageDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$esptool = "esptool.py"

Push-Location $packageDir
try {
    if ($Merged) {
        & $esptool --chip esp32s3 -p $Port -b 460800 --before default_reset --after hard_reset write_flash 0x0 merged-binary.bin
    } else {
        & $esptool --chip esp32s3 -p $Port -b 460800 --before default_reset --after hard_reset write_flash --flash_mode dio --flash_freq 80m --flash_size 16MB 0x0 bootloader/bootloader.bin 0x8000 partition_table/partition-table.bin 0xd000 ota_data_initial.bin 0x20000 xiaozhi.bin
    }
}
finally {
    Pop-Location
}
